%% random missing pixels
clear
clc
close all
data=load('images');
x_t=data.barbara;%the true image
p=0.9;%ratio of missing pixels
par1.type='SP';par1.seed=0;par1.sigma=0;par1.p=p;
[x_n,A]=DCA_add_noises(x_t,par1);%generate a noisy image
%please read the description of Group_DCA for more information
par.detail=1;
par.inpainting=0;
par.detect=0;
par.lambda=1;
par.type='SP';
par.t_c=2;
par.t_t=[0,0.2,0.4,0.6,0.7];
par.iter_out_min=length(par.t_t);
par.t_min=1;
par.t_mean=0;
par.max_thre=0.25;
par.iter_in_min=0;
par.c=0;
par.tol=[5e-04,1e-04];
par.maxiter=[100,100];
par.beta=10*par.lambda;
par.truegroup=0;
par.f=8;
par.spmax=60;
par.T=[8 4];
par.w=20;
par.s=4;
par.eps_min=1e-10;
par.x_t=x_t;
par.A_t=A;
fprintf(2,'Warning: this test may take more than 20 mins...\n')
[X,outc,outs]=Group_DCA(x_n,par);
fprintf('Done, see outc or outs for detailed results...\n')
%% missing blocks
clear
clc
close all
data=load('images');
x_t=data.x{1};%the true image patch, number 1~6
A=logical(data.mask);
x_n=x_t.*A;%generate a noisy image
%please read the description of Group_DCA for more information
par.detail=1;
par.inpainting=1;
par.detect=0;
par.lambda=1;
par.type='SP';
par.t_c=2;
par.t_t=[0,0.3,0.5,0.7,0.8];
par.iter_out_min=length(par.t_t);
par.t_min=1;
par.t_mean=0;
par.max_thre=0.25;
par.iter_in_min=0;
par.c=0;
par.tol=[5e-05,1e-05];
par.maxiter=[100,100];
par.beta=10*par.lambda;
par.truegroup=0;
par.f=16;
par.spmax=100;
par.T=[8 2];
par.w=50;
par.s=4;
par.eps_min=1e-10;
par.x_t=x_t;
par.A_t=A;
fprintf(2,'Warning: this test may take more than 5 mins...\n')
[X,outc,outs]=Group_DCA(x_n,par);
fprintf('Done, see outc or outs for detailed results...\n')