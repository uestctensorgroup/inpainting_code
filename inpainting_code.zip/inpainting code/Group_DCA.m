function [X_all,outc,outs]=Group_DCA(x_n,par)
%% Description
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%for solving model:
%min_X : \sum_i{lambda*(||Ri(X)||_{ti,*-F})+F(Ri(A.*X-x_n))} s.t. 0<=X<=1
%F(X)=\delta(X) for Salt & Pepper noise
%F(X)=1/2||X||_F^2 for Gaussian noise/Salt & Pepper plus Gaussian noise
%F(X)=||X||_1 for random valued noise
%A: 0 for unknown pixel (impulse noise), 1 for known pixel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%x_n: noisy image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%par: parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% detecting noise:
%  par.detect: detect noise or not; if do not detect, A is needed
%  par.filter_r: SP radius, needed if detect
%  par.filter_s: R thresholding, needed if detect
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% model:
%  par.lambda: regularization parameter
%  par.type: noise type
%      G: Gaussian
%      SP: Salt & Pepper noise
%      SPG: Salt & Pepper plus Gaussian noise
%      R: random valued noise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% t:
%  par.t: truncated number
%  par.t_c: adaptive selecting t or not
%  par.t_t: target thresholding
%  par.t_d: step length for increasing thresholding
%  par.t_min: impose minimal t
%  par.t_mean: normalize each group when computing t
%  par.iter_out_min: iteration number for selecting t
%  par.max_thre: thresholding for maximal t
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DCA:
%  par.c: DCA parameter
%  par.tol(1): tolerance (out)
%  par.maxiter(1): iteration number (out)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ADMM:
%  par.beta: ADMM parameter
%  par.tol(2): tolerance (inner)
%  par.maxiter(2): iteration number (inner)
%  par.iter_in_min: minimal iteration number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% block matching:
%  par.truegroup: use true image to group
%  par.f: patch size
%  par.s: patch step
%  par.w: window size
%  par.spmax: maximal similar patch number
%  par.bm: grouping mode
%  par.T: [updating group period, updating group time]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% others:
%  par.x_t: true image
%  par.A_t: 0 for unknown pixel (impulse noise), 1 for known pixel
%  par.eps_min: tolerance for small number to be regarded as zero
%  par.detail: show intermediate details
%  par.inpainting: compute PSNR for missing pixels only
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% parameter extraction
time_DCA=tic;
%detect
detect=par.detect;
%model
lambda=par.lambda;
type=par.type;
%t
t_c=par.t_c;
if t_c
    iter_out_min=par.iter_out_min;
else
    iter_out_min=0;
end
%dca/admm
c=par.c;
tol_out=par.tol(1);tol_in=par.tol(2);
maxiter_out=par.maxiter(1);maxiter_in=par.maxiter(2);
beta=par.beta;
iter_in_min=par.iter_in_min;
%BM
truegroup=par.truegroup;
f=par.f;if length(f)==1;f=[f f];end
T=1+(0:par.T(2))*par.T(1);
%others
x_t=par.x_t;
A_t=par.A_t;
detail=par.detail;
inpainting=par.inpainting;
%% intermediate data initialization
X_all=cell(1,maxiter_out);
t_all=cell(1,maxiter_out);
t_mean=zeros(1,maxiter_out);
t_max_all=cell(1,maxiter_out);
t_max_mean=zeros(1,maxiter_out);
cr_in=zeros(1,maxiter_out);
cr_x=zeros(1,maxiter_out);
cr_f=zeros(1,maxiter_out);
iter_in=zeros(1,maxiter_out);
con_Y=zeros(1,maxiter_out);
psn=zeros(1,maxiter_out);
ssi=zeros(1,maxiter_out);
bad_svt=zeros(1,maxiter_out);
fval=zeros(1,maxiter_out);
if ~inpainting
    psn_ini=PSNR(x_t,x_n);
    mean_org=mean(x_t(:));
else
    psn_ini=PSNR(x_t(~A_t),x_n(~A_t));
    mean_org=mean(x_t(~A_t));
end
%% initialization
sizeA=size(x_n);
X=zeros(sizeA);
%% DCA begin
for i=1:maxiter_out
    Xpout=X;
    %% noise detection, basic restoration, grouping, updating P
    %A: 0 for unknown pixel (impulse noise), 1 for known pixel
    if ismember(i,T)
        if i==1
            if detect
                A=noise_detection(x_n,par);
            else
                A=A_t;
            end
            if ~strcmp(type,'G') %&& ~inpainting
                u_basic=Delaunay_inpainting(x_n,A);%basic restoration
                u_basic(A)=x_n(A);
            else
                u_basic=x_n;
            end
            X=u_basic;
        elseif strcmp(type,'R')
            if par.detect
                A=noise_detection(X,par);
            else
                A=A_t;
            end
        end
        if truegroup
            if i==1
                [I_sp,W]=bm_inpainting(x_t,par,A);
                RX=makegroup(X,I_sp,f);
                S=num2cell(zeros(1,size(I_sp,2)));
                RtS=zeros(sizeA);
            end
        else
            [I_sp,W]=bm_inpainting(X,par,A);
            RX=makegroup(X,I_sp,f);
            if i==1 || inpainting
                S=num2cell(zeros(1,size(I_sp,2)));
                RtS=zeros(sizeA);
            end
        end
        i_t=1;
        t_now=zeros(1,size(I_sp,2));
    end
    [P,t_now,t_max_now]=compute_P(i_t,RX,I_sp,f,sizeA,par,t_now);
    i_t=i_t+1;
    %% ADMM
    if detail
        hbar=waitbar(0,'ADMM start');
    end
    for j=1:maxiter_in
        Xpin=X;
        %% compute Y
        [Y,bad_svt(i)]=compute_Y(RX,S,lambda,beta);
        RtY=imakegroup(Y,I_sp,f,sizeA);
        %% compute X
        X_temp=beta*(RtY+RtS)+P;
        %X=(RtY+RtS+lambda/beta*P)./W;
        switch type
            case 'SP'
                X=X_temp./((beta+2*c)*W);
                X(A)=x_n(A);
            case {'SPG','G'}
                X=(X_temp+A.*W.*x_n)./((A+beta+2*c).*W);
                %X(A)=(x_n(A)+beta*X(A))/(1+beta);
            case 'R'
                X=thresholdings(X_temp./((beta+2*c)*W)-x_n,A/(beta+2*c))+x_n;
                %X(A)=shrinkage(X(A)-x_n(A),1/beta)+x_n(A);
        end
        X=min(max(0,X),1);
        RX=makegroup(X,I_sp,f);
        %% update S
        [S,con_Y(i)]=updateS(S,RX,Y);
        RtS=imakegroup(S,I_sp,f,sizeA);
        %% inner iteration stopping
        cr_in1=norm(X-Xpin,'fro')/max(norm(Xpin,'fro'),par.eps_min);
        if detail
            waitbar(j/maxiter_in,hbar,sprintf('Out: %d, In: %d, Cr: %.4e',i,j,cr_in1));
        end
        if cr_in1<tol_in
            stop_flag=(i<T(end)+iter_out_min || j>=iter_in_min);
            if i==1 && j<=20
                stop_flag=0;
            end
            if stop_flag
                break;
            end
        end
    end
    if detail
        close(hbar);
    end
    %% outer iteration stopping
    cr_x1=norm(X-Xpout,'fro')/max(norm(Xpout,'fro'),par.eps_min);
    cr_x(i)=cr_x1;
    fval(i)=fun_fval(RX,X,x_n,A,lambda,type,W,t_now);
    if i>=2
        cr_fval=abs(fval(i)-fval(i-1))/max(fval(i-1),par.eps_min);
    else
        cr_fval=1;
    end
    cr_f(i)=cr_fval;
    stop_flag=(cr_fval<tol_out || cr_x1<tol_out) && i>T(end)+iter_out_min;
    cr_in(i)=cr_in1;
    iter_in(i)=j;
    X_all{i}=X;
    t_now_size=floor(sqrt(numel(t_now)));
    t_all{i}=reshape(t_now(1:(t_now_size^2)),t_now_size,t_now_size);
    t_mean(i)=mean(t_now);
    t_max_all{i}=reshape(t_max_now(1:(t_now_size^2)),t_now_size,t_now_size);
    %t_max_mean(i)=mean(min(t_max_now,1));
    t_max_mean(i)=mean(t_max_now>1);
    if ~inpainting
        psn(i)=PSNR(X,x_t);
        ssi(i)=ssim(X*255,x_t*255);
    else
        psn(i)=PSNR(X(~A_t),x_t(~A_t));
        ssi(i)=ssim(X*255,x_t*255);
    end
    if detail
        if i==1
            result_title='OutIt| InnIt|   PSNR|   SSIM|   OutCrX|   OutCrF|   InnCrX|  Trun#';
            disp(result_title)
        end
        result_sprintf=sprintf('%5d| %5d| %6.2f| %6.4f| %8.2e| %8.2e| %8.2e| %6.2f',...
            i,iter_in(i),psn(i),ssi(i),cr_x(i),cr_f(i),cr_in(i),t_mean(i));
        disp(result_sprintf)
        imshow(X)
        set(gcf,'position',get(0,'screensize'));
        title({result_title,result_sprintf})
        drawnow;
    end
    if stop_flag
        break;
    end
end
time_DCA=toc(time_DCA);
%% output
t_end=mean(t_now);
if ~inpainting
    psn_basic=PSNR(x_t,u_basic);
    psn_end=PSNR(x_t,X);
    mean_basic=mean(u_basic(:));
    mean_end=mean(X(:));
else
    psn_basic=PSNR(x_t(~A_t),u_basic(~A_t));
    psn_end=PSNR(x_t(~A_t),X(~A_t));
    mean_basic=mean(u_basic(~A_t));
    mean_end=mean(X(~A_t));
end
right=sum(sum(~A_t&~A))/max(sum(sum(~A_t)),1);%detected noisy pixels
wrong=sum(sum(A_t&~A))/max(sum(sum(~A_t)),1);%wrong detections
[outc,outs]=showvars({[6 3 3 5] i},...
    x_n,par,X,A,t_all,t_max_all,...
    i,time_DCA,t_end,...
    psn_ini,psn_basic,psn_end,...
    mean_org,mean_basic,mean_end,right,wrong,...
    psn,ssi,cr_x,cr_f,iter_in,cr_in,t_mean,t_max_mean,con_Y,bad_svt,fval);
end

function A=noise_detection(x_n,par)
switch par.type
    case 'G'
        A=true(size(x_n));
    case 'SP'
        [~,A]=adpmedft(x_n,par.filter_r);
        %        A=(u_basic~=x_n)&((x_n==1)|(x_n==0));
        A=~A;
    case 'SPG'
        A=(x_n==1)|(x_n==0);
        A=~A;
    case 'R'
        u_basic=x_n;
        for i=1:4
            u_basic=acwmf(u_basic,i,par.filter_s);
        end
        A=(u_basic==x_n);
end
end

function RX=makegroup(X,I_sp,f)
X_pat=makepatch(X,f,1);
group_num=size(I_sp,2);
RX=cell(1,group_num);
for i=1:group_num
    group_index=I_sp(:,i);
    group_index=group_index(group_index>0);
    RX{i}=X_pat(:,group_index);
end
end

function RtX=imakegroup(RX,I_sp,f,sizeA)
X_pat=zeros(f(1)*f(2),prod(sizeA-f+1));
group_num=size(I_sp,2);
for i=1:group_num
    group_index=I_sp(:,i);
    group_index=group_index(group_index>0);
    X_pat(:,group_index)=X_pat(:,group_index)+RX{i};
end
RtX=imakepatch(X_pat,f,sizeA,1);
end

function [Y,bad_svt]=compute_Y(RX,S,lambda,beta)
group_num=length(RX);
Y=cell(1,group_num);
bad_svt=0;
for i=1:group_num
    Y{i}=SVT(RX{i}-S{i},lambda/beta);
    if isequal(Y{i},zeros(size(Y{i})))
        bad_svt=bad_svt+1;
    end
end
bad_svt=bad_svt/group_num*100;
end

function [S,con_Y]=updateS(S,RX,Y)
%S=S+Y-X;
group_num=length(RX);
con_Y=0;
for i=1:group_num
    temp=Y{i}-RX{i};
    S{i}=S{i}+temp;
    con_Y=con_Y+norm(temp,'fro');
end
end

function [P,t_now,t_max_now]=compute_P(iter,RX,I_sp,f,sizeA,par,t_now)
group_num=length(RX);
t_max_now=zeros(1,group_num);
RP=cell(1,group_num);
for i=1:group_num
    [U,S_temp,V]=svd(RX{i},'econ');
    if all(size(S_temp)-1)
        S_temp=diag(S_temp);
    end
    S_temp=S_temp(:);
    r_temp=sum(S_temp>par.eps_min);%rank of RP{i}
    if isfield(par,'max_thre')
        t_max=sum(S_temp>(mean(S_temp)*par.max_thre));
    else
        t_max=r_temp;
    end
    S_temp=S_temp(1:r_temp);
    if par.t_mean
        S_temp_t=svd(RX{i}-mean(mean(RX{i})),'econ');
        r_temp_t=sum(S_temp_t>par.eps_min);
        S_temp_t=S_temp_t(par.t_min+1:r_temp_t);%compute t from par.t_min
    else
        S_temp_t=S_temp(par.t_min+1:r_temp);%compute t from par.t_min
    end
    switch par.t_c
        case 1
            if iter<=par.iter_out_min+1
                t_temp=find_t(S_temp_t,par.t_t-(par.iter_out_min-iter+1)*par.t_d)+par.t_min;
                t_max_now(i)=t_temp/t_max;
                t_temp=min(t_temp,t_max);
                t_now(i)=t_temp;
            else
                t_temp=t_now(i);
                t_max_now(i)=t_temp/t_max;
            end
        case 2
            if iter<=length(par.t_t)
                t_temp=find_t(S_temp_t,par.t_t(iter))+par.t_min;
                t_max_now(i)=t_temp/t_max;
                t_temp=min(t_temp,t_max);
                t_now(i)=t_temp;
            else
                t_temp=t_now(i);
                t_max_now(i)=t_temp/t_max;
            end
        case 0
            t_temp=par.t;
            t_now(i)=t_temp;
            t_max_now(i)=t_temp/t_max;
    end
    if r_temp<=t_temp
        P_temp=ones(r_temp,1);
    else
        P_temp=[ones(t_temp,1);S_temp(t_temp+1:r_temp)/norm(S_temp(t_temp+1:r_temp),'fro')];
    end
    RP{i}=par.lambda*U(:,1:r_temp)*diag(P_temp)*V(:,1:r_temp)'+2*par.c*RX{i};
end
P=imakegroup(RP,I_sp,f,sizeA);
end

function v=fun_fval(RX,X,x_n,A,lambda,type,W,t_now)
%min_X : \sum_i{lambda*(||Ri(X)||_{ti,*-F})+F(Ri(A.*X-x_n))} s.t. 0<=X<=1
%F(X)=\delta(X) for Salt & Pepper noise
%F(X)=1/2||X||_F^2 for Gaussian noise/Salt & Pepper plus Gaussian noise
%F(X)=||X||_1 for random valued noise
%A: 0 for unknown pixel (impulse noise), 1 for known pixel
v1=0;
for i=1:length(RX)
    v1=v1+PL1_L2norm(RX{i},t_now(i));
end
switch type
    case 'SP'
        v2=0;
    case {'SPG','G'}
        v2=1/2*sum(sum(W.*(A.*(X-x_n)).^2));
    case 'R'
        v2=sum(sum(W.*abs(A.*(X-x_n))));
end
v=lambda*v1+v2;
end

function val=PL1_L2norm(Z,t)
%for computing ||.||_{t,*+F}
s=svd(Z,'econ');
val=sum(s(t+1:end))-sqrt(sum(s(t+1:end).^2));
end

function u=Delaunay_inpainting(x_n,A)
%Delaunay
%A: 0 for unknown pixel (impulse noise), 1 for known pixel
[x1,x2]=find(A);
[y1,y2]=meshgrid(1:size(x_n,1),1:size(x_n,2));
u=griddata(x1,x2,x_n(A),y1,y2);
u=u';
if max(x_n(:))>=5
    MaxVal=255;
else
    MaxVal=1;
end
u(isnan(u))=0.5*MaxVal;
end

function t=find_t(X,a,type)
%find maximal t such that sum(X(1:t))<a (type=fixed) or
%sum(X(1:t))<a*sum(X(:)) (type=adaptive)
%(X,a) should be nonnegative
%X should be in descend order
X=sort(abs(X(:)),'descend');
if nargin==2
    type='adaptive';
end
if strcmp(type,'adaptive')
    a=a*sum(X);
end
if numel(X)==0 || X(1)>=a
    t=0;
    return;
end
n=length(X);
if sum(X)<a
    t=n;
    return;
end
tmin=1;
if sum(X(1:min(100,n)))>=a
    tmax=min(100,n);
else
    tmax=n;
end
while tmax-tmin>=2
    ttemp=floor((tmin+tmax)/2);
    if sum(X(1:ttemp))<a
        tmin=ttemp;
    else
        tmax=ttemp;
    end
    %disp([tmin tmax])
end
t=tmin;
end

function [I_sp,pixel_weight]=bm_inpainting(u,par,A)
%% parameter extraction
if ~exist('A','var') || isempty(A)
    A=false(size(u));
end
f=par.f;%patch size
if length(f)==1;f=[f f];end
spmax=par.spmax;%maximal number of patches
w=par.w;%window
if ~isfield(par,'inpainting_weight');par.inpainting_weight=1;end;inpainting_weight=par.inpainting_weight;
%%
f2=f(1)*f(2);
prmax=size(u,1)-f(1)+1;%maximal row number of patch left-top index
pcmax=size(u,2)-f(2)+1;%maximal column number of patch left-top index
if prmax<1 || pcmax<1
    error('wrong patch size')
end
mask=zeros(2*f-1);mask(1:f(1),1:f(2))=1;
A=imfilter(~A,mask,0,'conv');
A=logical(A(1:prmax,1:pcmax));%patches whose pixels containing in A
if ~isfield(par,'index')
    s=par.s;%step
    if length(s)==1;s=[s s];end
    pr=[1:s(1):(prmax-1) prmax];%patch left-top index row number set
    pc=[1:s(2):(pcmax-1) pcmax];%patch left-top index column number set
    prnum=length(pr);%number of reference patches in each column
    pcnum=length(pc);%number of reference patches in each row
    group_num=prnum*pcnum;%number of groups in X
    index=sub2ind([prmax pcmax],repmat(pr',[1,pcnum]),repmat(pc,[prnum,1]));
else
    if ~iscell(par.index)
        par.index={par.index};
    end
    group_num=length(par.index);
    index=zeros(1,group_num);
    for i=1:group_num
        index(i)=sub2ind([prmax pcmax],par.index{i}(1),par.index{i}(2));
    end
end
I_sp=zeros(spmax,group_num);
I_sp1=false(1,group_num);
X=makepatch(u,f,1);
X_weight=zeros(1,size(X,2));
I=reshape(1:(prmax*pcmax),prmax,pcmax);%patch index in u <=> column number of X
Ic=repmat(1:pcmax,[prmax,1]);%matrix of column number of patches in u
Ir=repmat((1:prmax)',[1,pcmax]);%matrix of row number of patches in u
%I(i,j): (i,j) is the index of patch in u, I(i,j) is the column number of
%this patch in X
%% main loop
for i=1:group_num
    p_X_index=index(i);%column number of current reference patch in X
    [row,col]=ind2sub([prmax pcmax],p_X_index);%row/column number of current reference patch
    % compute intersection of search window and u
    wrmin=max(row-w,1);
    wrmax=min(row+w,prmax);
    wcmin=max(col-w,1);
    wcmax=min(col+w,pcmax);
    w_index=I(wrmin:wrmax,wcmin:wcmax);%columns in X correspond to candidate patches
    w_c_index=Ic(wrmin:wrmax,wcmin:wcmax);%columns in u correspond to candidate patches
    w_r_index=Ir(wrmin:wrmax,wcmin:wcmax);%rows in u correspond to candidate patches
    %         if A(p_X_index)
    %             w_index=I(~A);w_c_index=Ic(~A);w_r_index=Ir(~A);
    %         else
    %             w_index=I(A);w_c_index=Ic(A);w_r_index=Ir(A);
    %         end
    w_index=w_index(:);w_c_index=w_c_index(:)';w_r_index=w_r_index(:)';
    w_dis_loc=(w_c_index-col).^2+(w_r_index-row).^2;%distances between candidate patches and reference patch
    [~,w_dis_loc_index]=sort(w_dis_loc);%sort distance
    w_index=w_index(w_dis_loc_index);%sort candidate patches as distance
    %considering distances so that if two candidate patches have the
    %same similarity, then the candidate patch near the reference one
    %will be considered first
    p_w=X(:,w_index);%candidate patches as columns of p_w, f2 by length(w_index)
    p_refer=X(:,p_X_index);%the reference patch
    dis_weight=ones(1,length(w_index));
    dis_weight((A(w_index)+A(p_X_index))==1)=inpainting_weight;
    %% computing similarities of patches in window
    w_dis=(p_w(1,:)-p_refer(1)).^2;
    for k=2:f2
        w_dis=w_dis+(p_w(k,:)-p_refer(k)).^2;
    end
    w_dis=w_dis/f2;
    w_dis=w_dis.*dis_weight;
    %w_dis is a row, w_dis(i) is the similarity of the ith candidate patch
    %% compute I_sp
    [~,w_dis_index]=sort(w_dis);%sort similarities
    w_sp_num_real=min(spmax,length(w_dis_index));%allowed number of patches
    index_temp=w_index(w_dis_index(1:w_sp_num_real));%core
    I_sp(1:w_sp_num_real,i)=index_temp;
    I_sp1(i)=any(A(index_temp));
    X_weight(index_temp)=X_weight(index_temp)+1;%compute how many times does each patch appear
end
I_sp=I_sp(:,I_sp1);
%% compute pixel_weight
X_weight=reshape(X_weight,[prmax pcmax]);
X_weight=padarray(X_weight,f-1,0,'post');
pixel_weight=imfilter(X_weight,mask,0,'corr');
end

function X=makepatch(u,f,isoverlap,single_vs_double)
%% Description
%generate matrix X to save all f(1)*f(2) patches in u
%isoverlap=1 (default) for overlapping patches
%if isoverlap=0 one needs f||size(u)
%single_vs_double for the format of u, double default
%each column of X is a vectorized patch in u
%columns in X from left to right correspond to patches in u from left-top to right-bottom
%order of patches is the default order of pixels of u, i.e., u(1) to u(end)
%since the number of columns of X is much larger than that of rows of X, we
%generate X row-by-row instead of column-by-column
if ~exist('isoverlap','var') || isempty(isoverlap)
    isoverlap=1;
end
if ~exist('single_vs_double','var') || isempty(single_vs_double)
    single_vs_double='double';
end
if length(f)==1;f=[f f];end
f1=f(1);f2=f(2);
switch isoverlap
    case 1
        step=[1 1];
    case 0
        if ~isequal(fix(size(u)./f),size(u)./f)
            error('size of u should be exactly divided by f')
        end
        step=f;
    otherwise
        error('wrong value of isoverlap')
end
pr=0:step(1):(size(u,1)-f1);%row numbers of patch left-top index -1
pc=0:step(2):(size(u,2)-f2);%column numbers of patch left-top index -1
pnum=length(pr)*length(pc);%maximal number of patches in u
switch single_vs_double
    case 'double'
        X=zeros(f1*f2,pnum);
    case 'single'
        X=zeros(f1*f2,pnum,'single');
end
k=0;
for i=1:f2
    for j=1:f1
        k=k+1;
        p_temp=u(pr+j,pc+i);
        X(k,:)=p_temp(:);
    end
end
end

function u=imakepatch(X,f,sizeu,isoverlap,isweight,weight)
%% Description
%inverse process of makepatch
%generate u by returning X row-by-row
if ~exist('isoverlap','var') || isempty(isoverlap)
    isoverlap=0;
end
if ~exist('isweight','var') || isempty(isweight)
    isweight=0;
end
if isweight
    if ~exist('weight','var') || isempty(weight)
        weight=ones(1,size(X,2));%weight for each patch
    end
    weight=weight(:)';
    X=X.*repmat(weight,size(X,1),1);
end
if length(f)==1
    f=[f f];
end
f1=f(1);f2=f(2);
X=double(X);
u=zeros(sizeu);
switch isoverlap
    case 1
        step=[1 1];
    case 0
        if ~isequal(fix(sizeu./f),sizeu./f)
            error('size of u should be exactly divided by f')
        end
        step=f;
    otherwise
        error('wrong value of isoverlap')
end
pr=0:step(1):(sizeu(1)-f1);%row numbers of patch left-top index -1
pc=0:step(2):(sizeu(2)-f2);%column numbers of patch left-top index -1
rnum=length(pr);%number of patches in each column
cnum=length(pc);%number of patches in each row
k=0;
for i=1:f2
    for j=1:f1
        k=k+1;
        u(pr+j,pc+i)=u(pr+j,pc+i)+reshape(X(k,:),[rnum cnum]);
    end
end
if isweight
    weight=reshape(weight,[rnum cnum]);
    weight1=zeros(sizeu);
    weight1(pr+1,pc+1)=weight;%weight for each patch
    weight=weight1;
    mask=zeros(2*f(1)-1,2*f(2)-1);mask(1:f(1),1:f(2))=1;
    weight=imfilter(weight,mask,0,'corr');%weight for each pixel
    u=u./weight;
end
end

function [A,As]=showvars(varargin)
%% 
flag=varargin{1};
a=flag{1};
if numel(flag)>1
    num=flag{2};
else 
    num=0;
end
var=varargin(2:end);
row=max(max(2*a),num+2);
name=cell(1,nargin-1);
for i=2:nargin
    name{i-1}=inputname(i);
end
%% 
n=length(a);
num1=sum(a);
A1=cell(row,n);
name1=name(1:num1);
var1=var(1:num1);
k=0;
for i=1:n
    for j=1:a(i)
        k=k+1;
        A1{2*j-1,i}=name1{k};
        A1{2*j,i}=var1{k};
    end
end
%% 
b=nargin-1-num1;
A2=cell(row,b);
name2=name(num1+1:num1+b);
var2=var(num1+1:num1+b);
for i=1:b
    A2(1:(num+2),i)=[name2{i} num2cell(var2{i}(1:num)) name2{i}];
end
%% 
A=[A1 A2];
%% 
for i=1:nargin-1
    As.(name{i})=var{i};
end
end

function X=SVT(Z,tau,type)
if nargin<3
    type='L1';
end
[m,n]=size(Z);
if m <= n
    AAT=Z*Z';
    [S,V]=eig(AAT);
    V=max(0,diag(V));
    %S=fliplr(S);
    %V=sort(diag(V),'descend');
    V=sqrt(V);
    tol=n*eps(max(V));
    mid=thresholdings(V,tau(end:-1:1),type);
    ind=mid>tol;
    if any(ind)
        mid=mid(ind)./V(ind);
        X=S(:,ind)*diag(mid)*S(:,ind)'*Z;
    else
        X=zeros(m,n);
    end
else
    X=SVT(Z',tau,type);
    X=X';
end
end

function x=thresholdings(y,tau,type)
%min_x: 1/2(x-y)^2+tau*f(x)
%type:
% 'L1': f(x)=|x|
% 'L1/2': f(x)=sqrt(x)
% 'TSL1':
%y=real(y);
if ~exist('type','var')
    type='L1';
end
switch type
    case 'L1'
        x=sign(y).*max(0,abs(y)-tau);
    case 'L1/2'
        ind=abs(y)>3/2*tau.^(2/3);
        x=zeros(size(y));
        y=y(ind);
        x(ind)=2/3*y.*(1+cos(2/3*(pi-acos(tau/4.*(abs(y)/3).^(-3/2)))));
end
end
