function [x_n,A]=DCA_add_noises(x_t,prob)
%prob:
% prob.type: 
%  'G'(Gaussian) 
%  'SP'(Salt & Pepper) 
%  'SPG'(Salt & Pepper plus Gaussian) 
%  'R'(Random value)
% prob.seed
% prob.sigma
% prob.p: unknown pixel level
% A: 0 for unknown pixel (impulse noise), 1 for known pixel
if isfield(prob,'seed')
    rand('seed',prob.seed);
    randn('seed',prob.seed);
end
switch prob.type
    case 'G'
        noise_g=1;
        noise_i=0;
    case 'SP'
        noise_g=0;
        noise_i=1;
    case 'SPG'
        noise_g=1;
        noise_i=1;
    case 'R'
        noise_g=0;
        noise_i=2;
end
x_n=x_t;A=true(size(x_t));
if noise_g
    x_n=x_t+prob.sigma*randn(size(x_t));
end
if noise_i
    total=numel(x_t);
    num=floor(total*prob.p);
    rand_sample=rand(1,total);
    [~,temp]=sort(rand_sample);
    temp=temp(1:num);
    A(temp)=false;
    switch noise_i
        case 1
            val=zeros(1,num);
            %val(1:floor(num/2))=1;
        case 2
            val=rand(1,num);
    end
    x_n(temp)=val;
end
end
